import os 

import dash
import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc
from dash.dependencies import Output, Input

from exposure.layouts import page_layouts


# print(dcc.__version__) # 0.6.0 or above is required
external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']


app = dash.Dash(__name__,external_stylesheets=[dbc.themes.BOOTSTRAP],suppress_callback_exceptions=True)

""" Default Layout"""
app.layout = html.Div([
    dcc.Location(id='url', refresh=False),
    html.Center([html.A(html.Img(src=app.get_asset_url("hartford.png"),
            id="logo",
            style={"width":100}), href='/'),

    # html.Title([html.H1('MLC Life Sciences Product Exposure'.upper(),id='main-title')]),
    html.H3('MLC Life Sciences Product Exposure'.upper(),id='title'),
    # content will be rendered in this element
    html.Div(id='page-content')])
])


"""CALLBACKS"""
#Callback to update input tag with suggested options
@app.callback(Output(component_id='list-suggested-inputs',
                     component_property='children'),
              [Input(component_id='product-input',
                     component_property='value')]
)
def update_datalist(value):
    if value:
        return [html.Option(value=value + 'spam')] * 3
    else:
        return []


#Callback to clear the Insured text box
@app.callback(Output("product-input","value"),
              Input("clear-insured-search-box","n_clicks")
)
def clear_insured_box(n_clicks):
    return ""

#Callback to display hidden values
# @app.callback(
#    [
#        Output(component_id='hidden-values', component_property='value'),
#        Output(component_id='hide-div', component_property='style'),
#    ],
#    [
#        Input(component_id="submit-insured-search-box", component_property='n_clicks'),
#        Input(component_id="product-input", component_property='value')
#     ]
# )
# def unhide(n_clicks,value):
#     if value:
#         markdown_string = f"""
#                         > Name:  **{value} - Name**
#                         > Address:  **{value} - Address**
#                         > State:  **{value} - State**
#                         > Zip:  **{value} - Zip**
#                         """
#         return markdown_string, {'display': 'block'}
    
        




#Callback to return proper layout
@app.callback(dash.dependencies.Output('page-content', 'children'),
              [dash.dependencies.Input('url', 'pathname')])
def display_page(pathname="/"):
    
    if pathname == "/product":
        return page_layouts.product_page_layout

    elif pathname == "/insert":
        return page_layouts.page_2_layout

    else:
        return page_layouts.index_layout


if __name__ == '__main__':
    app.run_server(debug=True,port=8051)