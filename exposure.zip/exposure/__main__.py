from exposure.app import app 


app.run_server(debug=True,port=8051)